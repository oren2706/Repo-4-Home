# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,json,requests

USER_AGENT = "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:52.0) Gecko/20100101 Firefox/52.0"
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     


###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder, iconimage="DefaultFolder.png",plot=' '):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+(plot)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name), "Plot": plot   })
          liz.setProperty( "Fanart_Image", iconimage )
          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)


def read_site_html(url_link):
    '''
    req = urllib2.Request(url_link)
    req.add_header('User-agent',USER_AGENT)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    '''
    html=requests.get(url_link).content
    return html
def get_plot(link_name):
    import datetime
    html=read_site_html('http://stream.israeltv.live/epg/%s.json'%link_name)
    json_data=json.loads(html)
    plot_final=''
    for val in json_data['epg']:

      name_val=val['title']
      time_val=datetime.datetime.fromtimestamp(int(val['start'])).strftime('%H:%M')
      if 'desc' in val:
        disc=val['desc']
      else:
        disc=''
      plot_final=plot_final+time_val+": "+name_val+" - "+disc+"\n"
    return plot_final
    
def main_menu():
    html=read_site_html('http://stream.israeltv.live/static/channels-new.js')
    
    regex='"(.+?)": {image: "(.+?)", title: "(.+?)"},'
    
    match=re.compile(regex).findall(html)

    
    for link_name,image,name in match:
        plot=get_plot(link_name)
        addLink( name, link_name,2,False, iconimage=image,plot=plot)
    
    regex='"(.+?)": {image: "(.+?)", title: "(.+?)", },'
    
    match=re.compile(regex).findall(html)

    
    for link_name,image,name in match:
        plot=get_plot(link_name)
        addLink( name, link_name,2,False, iconimage=image,plot=plot)
    regex='"(.+?)": {image: "(.+?)",sources.+?"(.+?)".+?,title: "(.+?)"}'
    
    match=re.compile(regex).findall(html)

    for link_name,image,link,name in match:
        plot=get_plot(link_name)
        addLink( name, link,2,False, iconimage=image,plot=plot)
    
    regex='"(.+?)": {image: "(.+?)", title: "(.+?)", sources:.+?"(.+?)"'
    
    match=re.compile(regex).findall(html)

    for link_name,image,name,link in match:
        link=link.replace(".mpd",".m3u8").replace("}","")
        plot=get_plot(link_name)
        addLink( name, link,2,False, iconimage=image,plot=plot)
    
def play_link(name,url,plot):
    if '//' not in url:
        import requests


        headers = {
            'Host': 'stream.israeltv.live',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'http://israeltv.live/1/%D7%97%D7%91%D7%99%D7%9C%D7%AA-%D7%91%D7%A1%D7%99%D7%A1',
            'Origin': 'http://israeltv.live',
            'Connection': 'keep-alive',
            'DNT': '1',
        }

        x=requests.get('http://stream.israeltv.live/live/%s.stream'%url, headers=headers).content
        logging.warning(x)
        regex='{ "file":"(.+?)"}'
        match=re.compile(regex).findall(x)
        play_link=match[0]
    else:
         play_link=url
    listItem = xbmcgui.ListItem(name, path=play_link+'|User-Agent=%s'%urllib.quote_plus(__USERAGENT__)) 
    listItem.setInfo(type='Video', infoLabels={"Title": name, "Plot": plot})

    listItem.setProperty('IsPlayable', 'true')

    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=(params["description"])
except:
        pass
   


if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
     play_link(name,url,description)
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmcplugin.addSortMethod(int(sys.argv[1]), 1)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

